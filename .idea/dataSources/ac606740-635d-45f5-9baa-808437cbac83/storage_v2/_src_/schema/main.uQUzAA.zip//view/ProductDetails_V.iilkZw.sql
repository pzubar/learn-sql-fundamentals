CREATE VIEW [ProductDetails_V] as select p.*, c.categoryname, c.description as [categorydescription], s.companyname as [suppliername], s.region as [supplierregion] from [Product] p join [Category] c on p.categoryid = c.id join [Supplier] s on s.id = p.supplierid;

